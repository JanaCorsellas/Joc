Version 5 generada por Enrique
Version 5 verificada por Jana
Version 5 comunicada por Aran
Link al video: https://www.youtube.com/watch?v=nNs3Ypv84P4








-std=c99 `mysql_config --cflags --libs`