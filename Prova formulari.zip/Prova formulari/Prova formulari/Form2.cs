﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace Prova_formulari
{
    
    public partial class Form2 : Form
    {
        private const int ScreenWidth = 770;
        private const int ScreenHeight = 420;

        public Form2()
        {
            InitializeComponent();
            ClientSize = new Size(ScreenWidth, ScreenHeight);
        }


        int velocidad = 7;
        int cont = 0; //contar els tocs, per augmentar la velocitat cada x tocs
        int puntuacio1 = 0;
        int puntuacio2 = 0;

        bool arriba;
        bool abajo;
        bool izquierda;
        bool derecha;

        private void Form2_Load(object sender, EventArgs e)
        {
            Random aleatorio = new Random();
            pilota.Location = new Point(385, aleatorio.Next(this.Height)); //la pilota surt a una posicio aleatoria de Y

            timer1.Enabled = true;
            puntuacio1 = 0;
            puntuacio2 = 0;
            this.KeyPreview = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (puntuacio1 == 7 || puntuacio2 == 7) //un dels dos equips marca 7 punts, s'acaba la partida
            {
                timer1.Enabled = false;
                MessageBox.Show("Game Over! Puntuació equip 1: " + puntuacio1.ToString() + " Puntuació equip 2: " + puntuacio2.ToString());
                puntuacio1 = 0;
                puntuacio2 = 0;
                velocidad = 7;
                cont = 0;
            }

            

            if (pilota.Width == J1.Width && pilota.Height == J1.Height)
            {
                pilota.Left += velocidad;
                cont += 1;
            }

            #region Moviment de la pilota


            if (izquierda)
            {
                pilota.Left += velocidad; //va para la derecha
            }
            else
            {
                pilota.Left -= velocidad; //va para la izquierda
            }

            if (arriba)
            {
                pilota.Top += velocidad; //va para abajo
            }

            else
            {
                pilota.Top -= velocidad; //va para arriba
            }

            if (pilota.Top >= this.Height - 50) //si pega a la paret de baix
            {
                arriba = false;
            }

            if (pilota.Top <= 0) //si pega a la paret de dalt
            {
                arriba = true;
            }

            #endregion

            if (pilota.Left > J3.Right && pilota.Left > J4.Right) //para cuando marca el equipo 1
            {
                timer1.Enabled = false;
                puntuacio1 = puntuacio1 + 1;
                cont = cont + 1;
                int count = int.Parse(textBox1.Text);
                count++;
                textBox1.Text = count.ToString();
            }
            if (pilota.Right < J1.Left && pilota.Right < J2.Left) //para cuando marca el equipo 2
            {
                timer1.Enabled = false;
                puntuacio2 = puntuacio2 + 1;
                cont = cont + 1;
                int count = int.Parse(textBox2.Text);
                count++;
                textBox2.Text = count.ToString();
            }
        }

        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case Keys.W:
                    Point p = J1.Location;
                    J1.Location = new Point(p.X, p.Y - 4);
                    break;
                case Keys.S:
                    Point j = J1.Location;
                    J1.Location = new Point(j.X, j.Y + 4);
                    break;
                //case Keys.Up:
                //    Point h = J1.Location;
                //    J1.Location = new Point(h.X, h.Y - 4);
                //    break;
                //case Keys.Right:
                //    Point g = J1.Location;
                //    J1.Location = new Point(g.X, g.Y + 4);
                //    break;
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Owner.Show(); //perq es torni a veure la pantalla d'inici
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //Rebot de la pilota
            if (pilota.Left + pilota.Width <= J1.Right && //verifica que estigui al rang d'esquerra a dreta del jugador
            pilota.Left + pilota.Width >= J1.Right + J1.Width && //verifica que no passi de la posició del jugador 1
            pilota.Top + pilota.Height >= J1.Top && //verifica que no es passi de la part de sobre del jugador 1 
                pilota.Top + pilota.Height <= J1.Top + J1.Height) //verifica que no es passi de la part de baix del jugador 1
            {
                derecha = false;
                cont += 1;
                this.Text = "Puntuació: " + puntuacio2.ToString() + "";
                cont += 1; //contador de tocs per augmentar la velocitat
                if (cont > 5) //cada vegada que es facin 5 tocs, la velocitat augmentarà i el contador tornarà a 0
                {
                    velocidad += 1;
                    cont = 0;
                }
            }
        }
    }
}
