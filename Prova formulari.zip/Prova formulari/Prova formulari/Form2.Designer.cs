﻿namespace Prova_formulari
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pilota = new System.Windows.Forms.Button();
            this.J1 = new System.Windows.Forms.PictureBox();
            this.J2 = new System.Windows.Forms.PictureBox();
            this.J3 = new System.Windows.Forms.PictureBox();
            this.J4 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.J1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pilota
            // 
            this.pilota.BackColor = System.Drawing.Color.Yellow;
            this.pilota.BackgroundImage = global::Prova_formulari.Properties.Resources.png_clipart_tennis_balls_green_tennis_glass_white;
            this.pilota.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pilota.Location = new System.Drawing.Point(385, 210);
            this.pilota.Name = "pilota";
            this.pilota.Size = new System.Drawing.Size(39, 35);
            this.pilota.TabIndex = 7;
            this.pilota.UseVisualStyleBackColor = false;
            // 
            // J1
            // 
            this.J1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.J1.Location = new System.Drawing.Point(168, 105);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(14, 50);
            this.J1.TabIndex = 8;
            this.J1.TabStop = false;
            // 
            // J2
            // 
            this.J2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.J2.Location = new System.Drawing.Point(168, 296);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(14, 50);
            this.J2.TabIndex = 9;
            this.J2.TabStop = false;
            // 
            // J3
            // 
            this.J3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.J3.Location = new System.Drawing.Point(619, 105);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(14, 50);
            this.J3.TabIndex = 10;
            this.J3.TabStop = false;
            // 
            // J4
            // 
            this.J4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.J4.Location = new System.Drawing.Point(619, 296);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(14, 50);
            this.J4.TabIndex = 11;
            this.J4.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(40, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(18, 31);
            this.textBox1.TabIndex = 12;
            this.textBox1.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(726, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(20, 31);
            this.textBox2.TabIndex = 13;
            this.textBox2.Text = "0";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.pilota);
            this.Name = "Form2";
            this.Text = "Juego";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Click += new System.EventHandler(this.Form2_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form2_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.J1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button pilota;
        private System.Windows.Forms.PictureBox J1;
        private System.Windows.Forms.PictureBox J2;
        private System.Windows.Forms.PictureBox J3;
        private System.Windows.Forms.PictureBox J4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Timer timer2;
    }
}