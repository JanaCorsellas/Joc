﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; //per dibuixar la posició de la imatge
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova_formulari
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int velocidad = 5;
        int cont = 0; //medir el puntaje
        int puntuacio1 = 0;
        int puntuacio2 = 0;

        bool arriba;
        bool izquierda;
        int posicion;

        private void PLAY(object sender, EventArgs e)
        {
            label1.BorderStyle = BorderStyle.FixedSingle;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label4.BorderStyle = BorderStyle.FixedSingle;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random aleatorio = new Random();
            pilota.Location = new Point(375, aleatorio.Next(this.Height)); //la pilota surt a una posicio aleatoria de Y
            arriba = true;
            izquierda = true;
            timer1.Enabled = true;
            puntuacio1 = 0;
            puntuacio2 = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (puntuacio1 == 7 || puntuacio2 == 7) //un dels dos equips marca 7 punts, s'acaba la partida
            {
                timer1.Enabled = false;
                MessageBox.Show("Game Over! Puntuació equip 1: " + puntuacio1.ToString() + " Puntuació equip 2: " +puntuacio2.ToString());
                puntuacio1 = 0;
                puntuacio2 = 0;
                velocidad = 5;
                cont = 0;
            }

            #region Moviment de la pilota


            if (izquierda)
            {
                pilota.Left += velocidad; //va para la derecha
            }
            else
            {
                pilota.Left -= velocidad; //va para la izquierda
            }

            if (arriba)
            {
                pilota.Top += velocidad; //va para abajo
            }

            else
            {
                pilota.Top -= velocidad; //va para arriba
            }

            if (pilota.Top >= this.Height - 50) //si pega a la paret de baix
            {
                arriba = false;
            }

            if(pilota.Top <= 0) //si pega a la paret de dalt
            {
                arriba = true;
            }

            if (pilota.Left >= 0) //dona a la paret de l'esquerra
            {
                izquierda = true; //perq es mogui cap a la dreta
            }

            if (pilota.Left >= this.Width - 20) //dona a la paret de la dreta
            {
                izquierda = false; //perq es mogui cap a la l'esquerra
            }

            #endregion
        }

        //if (pilota.Left > label3.Left && pilota.Left > label4.Left) para cuando marca el equipo 1

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case Keys.Up:
                    posicion = 0;
                    break;
                case Keys.Down:
                    posicion = 1;
                    break;
                case Keys.Left:
                    posicion = 2;
                    break;
                case Keys.Right:
                    posicion = 3;
                    break;

            }
        }
    }
}
